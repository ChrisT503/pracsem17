const data =[
  {
    fullName: "Jose Gonzale",
    email: "jg@gmail.com",
    password:""
  }
];

module.exports={data}